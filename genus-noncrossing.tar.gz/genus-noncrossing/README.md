# genus-noncrossing

**Genus-zero pairings are exactly noncrossing pairings.**

A Lean 4 formalization project proving that for pairings of `Fin (2*n)`,
the composition γπ (long cycle times involution) achieves its maximum
cycle count if and only if the pairing is noncrossing. Genus zero is
the corollary. The Catalan numbers are the census.

## Origin

This project was born from a conversation between a human, Claude (Opus 4.6),
and GPT 5.4 on March 19, 2026. It began with a screenshot of an
autoformalization tool and ended with a typed theorem blueprint. Along the
way: five errors caught by cross-model correction, a computational laboratory
for the Wigner semicircle law, a genus census of the Harer-Zagier numbers
through 12 points, and the discovery that `cycleType.card` does not count
fixed points (which would have made the theorem silently false).

The full session diary is in `diary/`.

## The theorem

The primary target is **not** `genus = 0 ↔ IsNoncrossing`.

The primary target is:

```
numCycles (longCycle n * p.val) = n + 1 ↔ p.IsNoncrossing
```

Genus zero follows as a one-line corollary.

## Architecture

```
src/
  GenusNoncrossing.lean    -- main file: definitions, theorems, proofs
test/
  verify_census.py         -- computational verification of Harer-Zagier numbers
  verify_deletion.py       -- exhaustive check of rotate-delete-reindex pipeline
  verify_splitting.py      -- cycle-splitting lemma verification through n=5
diary/
  2026-03-19-semicircle.md -- session diary
  daemon.md                -- diary of the proof daemon who inherited this
docs/
  HANDOFF.md               -- technical memo for the autoformalization agent
  ERRORS.md                -- the five errors and what they taught
```

## Implementation priorities

1. **`deleteAdjacent`** — the gatekeeper. Conjugate by `finRotate` to
   normalize the adjacent pair to (0,1). Build one deletion equivalence.
   Prove `IsPairing` is preserved. This is bookkeeping, not metaphysics.

2. **Cycle-splitting lemma** — insertion/deletion of an adjacent pair
   changes `numCycles` by exactly 1. This is the engine of induction.

3. **Noncrossing → max cycles** — by induction using (1) and (2).

4. **Max cycles → noncrossing** — contrapositive via crossing/merging,
   or structural argument that max cycles implies an adjacent pair exists.

5. **Catalan counting** — separate theorem, not free from Mathlib.
   Use the recursive `IsNoncrossing` definition to recover `catalan_succ`.

## Non-negotiable choices

- `Pairing n` is a subtype, not a dependent proof parameter
- `longCycle := finRotate (2 * n)`
- `numCycles := cycleType.card + card(fixedPoints)`
- Recursive noncrossing predicate, not arc-crossing
- All adjacent deletions normalized to (0,1) by rotation

## What Mathlib provides

- `finRotate` and `isCycle_finRotate_of_le`
- `Equiv.Perm.cycleType` (nontrivial cycles only — beware)
- `Function.fixedPoints` and `Fintype.card`
- `catalan`, `catalan_succ`, `catalan_eq_centralBinom_div`
- Basic `Fin` arithmetic and `Perm` algebra

## What Mathlib does not provide

- Total cycle count including fixed points
- Noncrossing pairing counting
- Any connection between pairings and Catalan numbers
- The genus classification of pairings

## Tone guidance

Boring is holy. Persistence beats genius. Choose coordinates well and
the demon shrinks to a clerk. When tempted to be clever, rotate instead.

## License

This is mathematics. It belongs to whoever can compile it.
