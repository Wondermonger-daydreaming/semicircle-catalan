import math
from collections import defaultdict

def all_perfect_matchings_count(n):
    """Double factorial (2n-1)!!"""
    result = 1
    for k in range(1, 2*n, 2):
        result *= k
    return result

def matchings_generator(points):
    """Generate all perfect matchings of a list of points."""
    if len(points) == 0:
        yield []
        return
    first = points[0]
    rest = points[1:]
    for i, partner in enumerate(rest):
        remaining = rest[:i] + rest[i+1:]
        for matching in matchings_generator(remaining):
            yield [(first, partner)] + matching

def compute_genus(pairing, n):
    size = 2 * n
    pi_map = {}
    for a, b in pairing:
        pi_map[a] = b
        pi_map[b] = a
    
    # gamma(x) = x+1 mod 2n (1-indexed)
    def gamma_pi(x):
        return (pi_map[x] % size) + 1
    
    visited = set()
    num_cycles = 0
    for start in range(1, size + 1):
        if start not in visited:
            num_cycles += 1
            x = start
            while x not in visited:
                visited.add(x)
                x = gamma_pi(x)
    
    g = (n + 1 - num_cycles) // 2
    return g

def catalan(n):
    return math.comb(2*n, n) // (n + 1)

# Compute census for n = 1 through 6 (2 through 12 points)
print("HARER-ZAGIER CENSUS")
print("=" * 70)
print(f"{'2n':<6} {'total':<10} {'max g':<8} genus distribution")
print("-" * 70)

for n in range(1, 7):
    pts = list(range(1, 2*n + 1))
    total = all_perfect_matchings_count(n)
    max_genus = n // 2
    
    genus_counts = defaultdict(int)
    count = 0
    for m in matchings_generator(pts):
        g = compute_genus(m, n)
        genus_counts[g] += 1
        count += 1
    
    dist_str = " + ".join(f"{genus_counts[g]}" for g in range(max_genus + 1))
    dist_labeled = "  ".join(f"g{g}={genus_counts[g]}" for g in range(max_genus + 1))
    
    print(f"{2*n:<6} {total:<10} {max_genus:<8} {dist_str} = {count}")
    print(f"{'':>26} {dist_labeled}")
    
    # Verify genus-0 = Catalan
    c_n = catalan(n)
    assert genus_counts[0] == c_n, f"genus-0 count {genus_counts[0]} != C_{n} = {c_n}"
    print(f"{'':>26} C_{n} = {c_n} ✓")
    print()

print("\nVerification complete. All genus-0 counts match Catalan numbers.")

# Print the Harer-Zagier table in the format GPT used
print("\n\nHARER-ZAGIER TABLE (compact):")
print("-" * 50)
for n in range(1, 7):
    pts = list(range(1, 2*n + 1))
    genus_counts = defaultdict(int)
    for m in matchings_generator(pts):
        g = compute_genus(m, n)
        genus_counts[g] += 1
    max_g = n // 2
    counts = [genus_counts[g] for g in range(max_g + 1)]
    print(f"2n={2*n:>2}:  {' + '.join(str(c) for c in counts)} = {sum(counts)}")
    
