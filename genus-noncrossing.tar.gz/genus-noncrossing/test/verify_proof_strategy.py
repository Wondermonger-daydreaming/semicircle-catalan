"""
Verify the key lemma in the proof strategy:
removing an adjacent pair from a noncrossing pairing
increases #cycles(γπ) by exactly 1.

And verify the contrapositive: any crossing forces
a cycle merger that reduces the cycle count.
"""
from collections import defaultdict

def compute_cycles(pairing, n):
    """Return the actual cycles of γπ, not just the count."""
    size = 2 * n
    pi_map = {}
    for a, b in pairing:
        pi_map[a] = b
        pi_map[b] = a
    
    def gamma_pi(x):
        return (pi_map[x] % size) + 1
    
    visited = set()
    cycles = []
    for start in range(1, size + 1):
        if start not in visited:
            cycle = []
            x = start
            while x not in visited:
                visited.add(x)
                cycle.append(x)
                x = gamma_pi(x)
            cycles.append(tuple(cycle))
    return cycles

def find_adjacent_pair(pairing, n):
    """Find a pair (i, i+1 mod 2n) in a noncrossing pairing."""
    size = 2 * n
    for a, b in pairing:
        if b == a + 1 or (a == size and b == 1) or (b == size and a == 1):
            return (min(a,b), max(a,b))
        if a == b + 1 or (b == a - 1):
            return (min(a,b), max(a,b))
    # Check cyclic adjacency (2n, 1)
    for a, b in pairing:
        if (a == 1 and b == size) or (a == size and b == 1):
            return (1, size)
    return None

def is_noncrossing(pairing):
    for i, (a1, b1) in enumerate(pairing):
        for j, (a2, b2) in enumerate(pairing):
            if i >= j: continue
            lo1, hi1 = min(a1, b1), max(a1, b1)
            lo2, hi2 = min(a2, b2), max(a2, b2)
            if lo1 < lo2 < hi1 < hi2: return False
            if lo2 < lo1 < hi2 < hi1: return False
    return True

def matchings_generator(points):
    if len(points) == 0:
        yield []
        return
    first = points[0]
    rest = points[1:]
    for i, partner in enumerate(rest):
        remaining = rest[:i] + rest[i+1:]
        for matching in matchings_generator(remaining):
            yield [(first, partner)] + matching

# ============================================================
# VERIFY: every noncrossing pairing has an adjacent pair
# ============================================================
print("LEMMA 1: Every noncrossing pairing has an adjacent pair")
print("=" * 55)
for n in range(1, 5):
    pts = list(range(1, 2*n + 1))
    all_nc = []
    for m in matchings_generator(pts):
        if is_noncrossing(m):
            adj = find_adjacent_pair(m, n)
            all_nc.append((m, adj))
            if adj is None:
                print(f"  COUNTEREXAMPLE at n={n}: {m} has no adjacent pair!")
    
    all_have_adj = all(adj is not None for _, adj in all_nc)
    print(f"  n={n} (2n={2*n}): {len(all_nc)} noncrossing pairings, "
          f"all have adjacent pair: {all_have_adj}")

# ============================================================
# VERIFY: removing adjacent pair increases cycle count by 1
# ============================================================
print(f"\nLEMMA 2: Removing adjacent pair increases #cycles(γπ) by 1")
print("=" * 60)

for n in range(2, 5):
    pts = list(range(1, 2*n + 1))
    all_ok = True
    for m in matchings_generator(pts):
        if not is_noncrossing(m):
            continue
        
        cycles_before = compute_cycles(m, n)
        nc_before = len(cycles_before)
        
        # Find adjacent pair
        adj = find_adjacent_pair(m, n)
        if adj is None:
            continue
        
        # Remove the adjacent pair and relabel
        a, b = adj
        remaining = [(x, y) for x, y in m if not ({x,y} == {a,b})]
        
        # Relabel: remove a and b from {1,...,2n}, compact to {1,...,2(n-1)}
        removed = sorted([a, b])
        old_to_new = {}
        new_idx = 1
        for k in range(1, 2*n + 1):
            if k not in removed:
                old_to_new[k] = new_idx
                new_idx += 1
        
        new_pairing = [(old_to_new[x], old_to_new[y]) for x, y in remaining]
        cycles_after = compute_cycles(new_pairing, n - 1)
        nc_after = len(cycles_after)
        
        delta = nc_before - nc_after
        if delta != 1:
            print(f"  n={n}: UNEXPECTED delta={delta} for {m}, adj={adj}")
            print(f"    before: {nc_before} cycles {cycles_before}")
            print(f"    after:  {nc_after} cycles {cycles_after}")
            all_ok = False
    
    if all_ok:
        print(f"  n={n}: all noncrossing pairings verified: "
              f"removing adjacent pair gives Δ(#cycles) = +1 ✓")
    # Note: the convention matters. When we remove two points and
    # reduce n, the formula genus = (n+1-c)/2 should give
    # genus_before = ((n)+1 - c_before)/2 = 0
    # genus_after = ((n-1)+1 - c_after)/2 = 0
    # So c_before = n+1 and c_after = n, meaning c_before - c_after = 1.

# ============================================================
# VERIFY: genus 0 ↔ #cycles = n+1 (exact characterization)
# ============================================================
print(f"\nMAIN THEOREM CHECK: genus 0 iff noncrossing")
print("=" * 50)
for n in range(1, 6):
    pts = list(range(1, 2*n + 1))
    mismatches = 0
    total = 0
    for m in matchings_generator(pts):
        total += 1
        cycles = compute_cycles(m, n)
        nc = len(cycles)
        genus = (n + 1 - nc) // 2
        noncross = is_noncrossing(m)
        
        if (genus == 0) != noncross:
            mismatches += 1
            print(f"  MISMATCH at n={n}: {m}, genus={genus}, noncrossing={noncross}")
    
    print(f"  n={n} (2n={2*n}): checked {total} pairings, "
          f"genus=0 ↔ noncrossing: {'✓ PERFECT' if mismatches == 0 else f'{mismatches} MISMATCHES'}")

