"""
Final verification: the cycle-splitting lemma at n=4 and n=5,
showing exactly how the cycle structure changes when we insert
an adjacent pair.
"""

def compute_full_cycle_info(pairing, n):
    size = 2 * n
    pi_map = {}
    for a, b in pairing:
        pi_map[a] = b
        pi_map[b] = a
    def gamma_pi(x):
        return (pi_map[x] % size) + 1
    visited = set()
    cycles = []
    for start in range(1, size + 1):
        if start not in visited:
            cycle = []
            x = start
            while x not in visited:
                visited.add(x)
                cycle.append(x)
                x = gamma_pi(x)
            cycles.append(tuple(cycle))
    return cycles

# Take a noncrossing pairing on 8 points with adjacent pair (3,4)
# and show what happens when we remove it

p_8 = [(1,2), (3,4), (5,8), (6,7)]  # noncrossing on 8 points

cycles_8 = compute_full_cycle_info(p_8, 4)
print(f"Pairing on 8 points: {p_8}")
print(f"γπ cycles: {cycles_8}")
print(f"numCycles = {len(cycles_8)}, expected n+1 = 5")

# Remove (3,4) and relabel {1,2,5,6,7,8} → {1,2,3,4,5,6}
p_6 = [(1,2), (3,6), (4,5)]  # what remains after relabeling

cycles_6 = compute_full_cycle_info(p_6, 3)
print(f"\nAfter removing (3,4) and relabeling: {p_6}")
print(f"γπ cycles: {cycles_6}")
print(f"numCycles = {len(cycles_6)}, expected n+1 = 4")
print(f"Delta = {len(cycles_8) - len(cycles_6)} (should be 1)")

print("\n" + "="*50)

# Another example: (1,6)(2,3)(4,5) on 6 points, adjacent pair (2,3)
p2 = [(1,6), (2,3), (4,5)]
cycles_p2 = compute_full_cycle_info(p2, 3)
print(f"\nPairing on 6 points: {p2}")
print(f"γπ cycles: {cycles_p2}")
print(f"numCycles = {len(cycles_p2)}")

# Remove (2,3), relabel {1,4,5,6} → {1,2,3,4}
p2_reduced = [(1,4), (2,3)]
cycles_p2r = compute_full_cycle_info(p2_reduced, 2)
print(f"After removing (2,3) and relabeling: {p2_reduced}")
print(f"γπ cycles: {cycles_p2r}")
print(f"numCycles = {len(cycles_p2r)}")
print(f"Delta = {len(cycles_p2) - len(cycles_p2r)} (should be 1)")

# Verify for ALL noncrossing pairings at n=4,5 that the splitting works
print("\n" + "="*50)
print("EXHAUSTIVE SPLITTING VERIFICATION")

def matchings_generator(points):
    if len(points) == 0:
        yield []
        return
    first = points[0]
    rest = points[1:]
    for i, partner in enumerate(rest):
        remaining = rest[:i] + rest[i+1:]
        for matching in matchings_generator(remaining):
            yield [(first, partner)] + matching

def is_noncrossing(pairing):
    for i, (a1, b1) in enumerate(pairing):
        for j, (a2, b2) in enumerate(pairing):
            if i >= j: continue
            lo1, hi1 = min(a1, b1), max(a1, b1)
            lo2, hi2 = min(a2, b2), max(a2, b2)
            if lo1 < lo2 < hi1 < hi2: return False
            if lo2 < lo1 < hi2 < hi1: return False
    return True

for n in range(1, 6):
    pts = list(range(1, 2*n + 1))
    count = 0
    ok = 0
    for m in matchings_generator(pts):
        if not is_noncrossing(m): continue
        count += 1
        cycles = compute_full_cycle_info(m, n)
        assert len(cycles) == n + 1, f"noncrossing pairing {m} has {len(cycles)} cycles, expected {n+1}"
        ok += 1
    print(f"n={n}: all {ok}/{count} noncrossing pairings have exactly {n+1} cycles ✓")

