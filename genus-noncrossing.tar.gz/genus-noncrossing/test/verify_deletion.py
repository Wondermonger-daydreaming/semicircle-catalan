"""
Verify the rotation-to-(0,1) trick for deleteAdjacent,
and build the concrete embedding Fin(2n-2) -> Fin(2n) \ {0,1}.

The strategy:
1. Given pairing p with adjacent pair at position i (p(i) = i+1 mod 2n),
   conjugate by finRotate^(-i) to move the pair to (0,1).
2. The conjugated pairing p' = rot^(-i) * p * rot^i has p'(0) = 1.
3. Delete {0,1} from the domain. The remaining points {2,...,2n-1}
   are order-isomorphic to Fin(2n-2) via the map j -> j-2.
4. The restricted, reindexed permutation is again a pairing.
"""
import numpy as np
from collections import defaultdict

def apply_perm(pi_map, x, size):
    return pi_map[x]

def compose_perms(f, g, size):
    """f after g: (f∘g)(x) = f(g(x))"""
    result = {}
    for x in range(size):
        result[x] = f[g[x]]
    return result

def invert_perm(pi_map, size):
    result = {}
    for x in range(size):
        result[pi_map[x]] = x
    return result

def make_rotation(size, power=1):
    """finRotate^power: x -> (x + power) mod size"""
    return {x: (x + power) % size for x in range(size)}

def make_pairing_map(pairing, n):
    """Convert list of pairs (1-indexed) to 0-indexed dict."""
    size = 2 * n
    pi = {}
    for a, b in pairing:
        pi[a-1] = b-1
        pi[b-1] = a-1
    return pi

def is_fpf_involution(pi, size):
    """Check fixed-point-free involution."""
    for x in range(size):
        if pi[x] == x:
            return False, f"fixed point at {x}"
        if pi[pi[x]] != x:
            return False, f"not involution at {x}"
    return True, "ok"

def find_adjacent(pi, size):
    """Find i such that pi(i) = (i+1) mod size."""
    for i in range(size):
        if pi[i] == (i + 1) % size:
            return i
    return None

def delete_and_reindex(pi, size):
    """
    Given pi with pi(0) = 1, delete {0,1} and reindex.
    The remaining points {2, 3, ..., size-1} map to {0, 1, ..., size-3}
    via j -> j - 2.
    """
    new_size = size - 2
    new_pi = {}
    for j in range(2, size):
        target = pi[j]
        assert target >= 2, f"pi({j}) = {target} maps back into deleted set!"
        new_pi[j - 2] = target - 2
    return new_pi, new_size

# Test on known noncrossing pairings
print("ROTATION-TO-(0,1) TRICK VERIFICATION")
print("=" * 60)

test_cases = [
    # (n, pairing as 1-indexed pairs, which pair is adjacent)
    (3, [(1,2), (3,6), (4,5)], "adjacent at 1↔2"),
    (3, [(1,6), (2,3), (4,5)], "adjacent at 2↔3"),
    (3, [(1,4), (2,3), (5,6)], "adjacent at 2↔3"),
    (4, [(1,2), (3,4), (5,8), (6,7)], "adjacent at 1↔2"),
    (4, [(1,8), (2,3), (4,7), (5,6)], "adjacent at 2↔3"),
]

for n, pairing, desc in test_cases:
    size = 2 * n
    pi = make_pairing_map(pairing, n)
    
    print(f"\nn={n}, pairing={pairing} ({desc})")
    
    # Find adjacent pair
    adj = find_adjacent(pi, size)
    assert adj is not None, "no adjacent pair found!"
    print(f"  Adjacent pair at position {adj}: π({adj}) = {pi[adj]}")
    
    # Conjugate by rot^(-adj) to move adjacent pair to (0,1)
    rot = make_rotation(size, 1)
    rot_neg = make_rotation(size, -adj)  # rot^(-adj)
    rot_pos = make_rotation(size, adj)   # rot^(adj) = inverse of rot^(-adj)
    
    # p' = rot^(-adj) * p * rot^(adj)
    # i.e., p'(x) = rot^(-adj)(p(rot^(adj)(x)))
    conj = compose_perms(rot_neg, compose_perms(pi, rot_pos, size), size)
    
    print(f"  Conjugated: π'(0) = {conj[0]}, π'(1) = {conj[1]}")
    assert conj[0] == 1 and conj[1] == 0, "conjugation didn't move pair to (0,1)!"
    
    # Verify conjugated is still a pairing
    ok, msg = is_fpf_involution(conj, size)
    assert ok, f"conjugated is not a pairing: {msg}"
    print(f"  Conjugated is a valid pairing: ✓")
    
    # Now delete {0,1} and reindex
    # First verify that no remaining point maps to {0,1}
    maps_to_deleted = [j for j in range(2, size) if conj[j] < 2]
    assert len(maps_to_deleted) == 0, f"points {maps_to_deleted} map into deleted set!"
    
    new_pi, new_size = delete_and_reindex(conj, size)
    print(f"  After deleting {{0,1}} and reindexing: size {new_size}")
    
    # Verify the result is a pairing on the smaller set
    ok2, msg2 = is_fpf_involution(new_pi, new_size)
    assert ok2, f"reduced pairing is not valid: {msg2}"
    print(f"  Reduced pairing is valid: ✓")
    
    # Show the reduced pairing
    pairs = []
    seen = set()
    for j in range(new_size):
        if j not in seen:
            pairs.append((j, new_pi[j]))
            seen.add(j)
            seen.add(new_pi[j])
    print(f"  Reduced pairs (0-indexed): {pairs}")

print("\n" + "=" * 60)
print("EXHAUSTIVE VERIFICATION: all noncrossing pairings, n=1..5")
print("=" * 60)

def matchings_gen(points):
    if len(points) == 0:
        yield []
        return
    first = points[0]
    rest = points[1:]
    for i, partner in enumerate(rest):
        remaining = rest[:i] + rest[i+1:]
        for m in matchings_gen(remaining):
            yield [(first, partner)] + m

def is_noncrossing(pairing):
    for i, (a1, b1) in enumerate(pairing):
        for j, (a2, b2) in enumerate(pairing):
            if i >= j: continue
            lo1, hi1 = min(a1, b1), max(a1, b1)
            lo2, hi2 = min(a2, b2), max(a2, b2)
            if lo1 < lo2 < hi1 < hi2: return False
            if lo2 < lo1 < hi2 < hi1: return False
    return True

for n in range(1, 6):
    size = 2 * n
    pts = list(range(1, size + 1))
    total_nc = 0
    total_ok = 0
    
    for m in matchings_gen(pts):
        if not is_noncrossing(m): continue
        total_nc += 1
        
        pi = make_pairing_map(m, n)
        adj = find_adjacent(pi, size)
        
        if adj is None:
            print(f"  FAIL: noncrossing pairing {m} has no adjacent pair!")
            continue
        
        # Conjugate
        rot_neg = make_rotation(size, -adj)
        rot_pos = make_rotation(size, adj)
        conj = compose_perms(rot_neg, compose_perms(pi, rot_pos, size), size)
        
        assert conj[0] == 1 and conj[1] == 0
        
        # Check no remaining point maps to deleted set
        clean = all(conj[j] >= 2 for j in range(2, size))
        assert clean, f"pairing {m} has points mapping back to deleted set after conjugation!"
        
        # Delete and check
        if n > 1:
            new_pi, new_size = delete_and_reindex(conj, size)
            ok, _ = is_fpf_involution(new_pi, new_size)
            assert ok
        
        total_ok += 1
    
    print(f"n={n}: {total_ok}/{total_nc} noncrossing pairings survive "
          f"rotate-delete-reindex ✓")

print("\n✓ The rotation trick works for every noncrossing pairing through n=5.")
print("  deleteAdjacent is safe to implement in Lean.")
