# The Five Errors

Every error in this project's history was caught by cross-model correction.
Each one made the mathematics more honest. They are documented here not as
confession but as infrastructure.

## 1. The normalization error

**What happened:** Claude wrote the semicircle density on [-1,1] as
f(x) = (2/π)√(1-x²) and claimed the even moments are the Catalan numbers.
They are not. They are Cₙ/4ⁿ. The exact Catalans require the [-2,2] scaling:
ρ(x) = (1/2π)√(4-x²).

**Who caught it:** GPT 5.4.

**What it taught:** Scale is destiny in random matrix theory. A missing
factor of 2 changes whether your moments are Cₙ or Cₙ/4ⁿ. The semicircle
is elegant but not forgiving. It expects you to respect its units.

## 2. The tipsy data

**What happened:** Claude observed that empirical moments at small N
overshot their Catalan targets and declared these "ghost signatures of
non-planar topology" in the genus expansion.

**Who caught it:** GPT 5.4.

**What it taught:** The narrative was directionally correct but the data
was a handful of averaged samples at four matrix sizes. "Consistent with"
is not "established by." The overshoot pattern deserves the genus-expansion
interpretation, but the evidence as presented was "a bit tipsy." Always
pressure-test claims against sample size.

## 3. The ensemble elision

**What happened:** Claude presented the 1/N² genus expansion as if it
applied directly to the real symmetric (GOE) matrices in our computational
lab. The clean genus expansion is native to the Gaussian Unitary Ensemble
(GUE/Hermitian). For the GOE, non-orientable surfaces can intrude and
the expansion includes odd powers of 1/N.

**Who caught it:** GPT 5.4.

**What it taught:** The topology is in the room, but the room has more
furniture than just orientable genus. The distinction between GOE and GUE
is not a footnote — it changes the combinatorial bookkeeping of the
entire expansion.

## 4. The impossible genera

**What happened:** Claude suggested that genus 2 might appear at 6 points
and genus 3 at 10 points.

**Who caught it:** GPT 5.4.

**What it taught:** The maximum genus for pairings of 2n points is ⌊n/2⌋.
At 6 points (n=3): only g=0,1. At 8 points (n=4): g=0,1,2. At 10 points
(n=5): still only g=0,1,2. Genus 3 first appears at 12 points (n=6).
The combinatorial real estate is finite. Always compute the bound.

## 5. The cycleType.card bug

**What happened:** The Lean sketch used `cycleType.card` as the total
cycle count in the genus formula. Mathlib's `cycleType` records only
nontrivial cycles (length ≥ 2). Fixed points are omitted.

**Who caught it:** GPT 5.4.

**What it taught:** For γπ = (1,3,5)(2)(4)(6), cycleType.card = 1
but the correct total cycle count is 4. Using cycleType.card alone
would compute genus = (4-1)/2 = 1 for a pairing that is actually
genus 0. The theorem would have been *false*. The repair:
numCycles = cycleType.card + card(fixedPoints). This is the kind of
error that purrs.

## The pattern

Claude's errors were consistently errors of overreach: claiming more
than the data supported, using API functions based on assumed behavior,
suggesting combinatorial possibilities without checking bounds. GPT's
corrections were consistently acts of precision: checking actual docs,
computing actual bounds, verifying actual API behavior. The human
(Tomás) provided direction and demanded honesty.

The crossing pairings died in the large-N audit. So did these errors.
Both clarified the law.
